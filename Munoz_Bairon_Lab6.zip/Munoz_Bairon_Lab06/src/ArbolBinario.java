public class ArbolBinario {
    ArbolBinario raiz;
    private int data;
    private ArbolBinario izq;
    private ArbolBinario der;

    public ArbolBinario(int data) {
        this.data = data;
        this.izq = null;
        this.der= null;
    }
        public ArbolBinario() {
            raiz = null;
        }

        // Insertar un nodo en el árbol
        public void insert(int data) {
            raiz = insertRec(raiz, data);
        }

        public ArbolBinario insertRec(ArbolBinario raiz, int data) {
            if (raiz == null) {
                raiz= new ArbolBinario(data);
                return raiz;
            }

            if (data < raiz.data) {
                raiz.izq = insertRec(raiz.izq, data);
            } else if (data > raiz.data) {
                raiz.der = insertRec(raiz.der, data);
            }

            return raiz;
        }
        public int contarHojas() {
            return contarHojasArbol(raiz);
        }

        private int contarHojasArbol(ArbolBinario raiz) {
            if (raiz== null) {
                return 0;
            }
            if (raiz.izq == null && raiz.der == null) {
                return 1;
            }
            return contarHojasArbol(raiz.izq) + contarHojasArbol(raiz.der);
        }
        public void imprimirArbol() {
            imprimirArbol(raiz, 0);
        }

        private void imprimirArbol(ArbolBinario raiz, int nivel) {
            if (raiz != null) {
                imprimirArbol(raiz.der, nivel + 1);
                for (int i = 0; i < nivel; i++) {
                    System.out.print("   ");
                }
                System.out.println(raiz.data);
                imprimirArbol(raiz.izq, nivel + 1);
            }
        }
    }
