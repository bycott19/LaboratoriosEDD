public class Main {
    public static void main(String[] args) {

        ArbolBinario arbol = new ArbolBinario();
        for(int i=0; i<20; i++){
            arbol.insert(i);
        }
        System.out.println("Árbol en orden ascendente: ");
        arbol.imprimirArbol();
        System.out.println();

        // Contar las hojas del árbol
        int hojas = arbol.contarHojas();
        System.out.println("Número de hojas en el árbol: " + hojas);
    }
}
