import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Arbol arbol = new Arbol();
        String texto;

        do{
            System.out.print("Ejemplo de ruta: ");
            System.out.println("C:\\Users\\bycot\\IdeaProjects\\Muñoz_Bairon-Tarea1\\Tarea1/archivo.txt");
            System.out.print("Ingrese la ruta: ");
            String ruta = sc.nextLine().trim();
            texto = arbol.archivo(ruta);
        }while (texto == null);

        arbol.paginas(arbol, texto);
        arbol.imprimir();
        System.out.println();

        String salida = "";
        while (!salida.equalsIgnoreCase("s")){
            buscarPalabra(sc, arbol);
            System.out.print("pulse (s) para salir o (c) para continuar: ");
            salida = sc.nextLine();
            while (!salida.equalsIgnoreCase("c") && !salida.equalsIgnoreCase("s")){
                System.out.println("La opción ingresada no es valida");
                salida = sc.nextLine();
            }
        }
    }
    public static void buscarPalabra(Scanner sc, Arbol arbol){
        System.out.print("Ingrese la palabra: ");
        String palabra = sc.nextLine().trim();
        System.out.println(arbol.nodoToString(arbol.buscar(palabra)));
    }
}