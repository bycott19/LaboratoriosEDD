import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Arbol {
    NodoAVL raiz;

    public class NodoAVL {
        int altura;
        String llave;
        NodoAVL izquierda;
        NodoAVL derecha;
        HashMap<Integer, Integer> paginas;

        NodoAVL(String d, int pagina) {
            llave = d;
            altura = 1;
            paginas = new HashMap<Integer, Integer>();
            paginas.put(pagina, 1);
        }
    }
    // Rotaciones
    private NodoAVL rotaDerecha(NodoAVL a) {
        NodoAVL temp = a.izquierda;
        a.izquierda = temp.derecha;
        temp.derecha = a;
        return temp;
    }
    private NodoAVL rotaIzquierda(NodoAVL a) {
        NodoAVL temp = a.derecha;
        a.derecha = temp.izquierda;
        temp.izquierda = a;
        return temp;
    }

    // O
    private int altura(NodoAVL nodoActual) {
        if (nodoActual == null) return 0;

        return nodoActual.altura;
    }
    private int maximo(int a, int b) {
        return (a > b) ? a : b;
    }

    // Obtiene el factor de balance de un nodo
    private int getBalance(NodoAVL nodoActual) {
        if (nodoActual == null) return 0;
        return altura(nodoActual.izquierda) - altura(nodoActual.derecha);
    }

    public NodoAVL buscar(String key){
        return buscar(key, raiz);
    }


    public NodoAVL buscar(String key, NodoAVL nodoActual){
        if(nodoActual == null) return null;
        if (nodoActual.llave.equalsIgnoreCase(key)) return nodoActual;
        if (key.compareToIgnoreCase(nodoActual.llave) < 0){
            return buscar(key, nodoActual.izquierda);
        }else{
            return buscar(key, nodoActual.derecha);
        }
    }

    public void imprimir(){
        imprimir(raiz, "");
    }

    private String imprimir(NodoAVL nodoActual, String inicialAnterior){
        if(nodoActual.izquierda != null) inicialAnterior = imprimir(nodoActual.izquierda, inicialAnterior);

        String inicialActual = nodoActual.llave.substring(0, 1);

        if(!inicialAnterior.equalsIgnoreCase(inicialActual)){
            inicialAnterior = inicialActual;
            System.out.println("-" + inicialAnterior.toUpperCase() + "-");
        }

        System.out.println(nodoToString(nodoActual));

        if(nodoActual.derecha != null) inicialAnterior = imprimir(nodoActual.derecha, inicialAnterior);

        return inicialAnterior;
    }

    public String nodoToString(NodoAVL nodoActual){
        if(nodoActual == null) return "Palabra no encontrada.";
        String texto = nodoActual.llave;

        int i = 0;
        for (Integer clave : nodoActual.paginas.keySet()) {
            i++;
            Integer valor = nodoActual.paginas.get(clave);
            if(valor == 1){
                texto = String.format("%s %d", texto, clave);
            }else if(valor > 1){
                texto = String.format("%s %d(%d)", texto, clave, valor);
            }
            if(i < nodoActual.paginas.size()) texto = String.format("%s,", texto);
        }

        return texto;
    }
    public void paginas (Arbol arbol, String texto){
        String[] textoXPagina = texto.split("\\|");
        for(int pagina = 0; pagina<textoXPagina.length; pagina++) {
            Pattern pattern = Pattern.compile("\\\\([^\\\\]+)\\\\");
            Matcher matcher = pattern.matcher(textoXPagina[pagina]);
            while (matcher.find()) {
                String palabra = matcher.group(1);
                arbol.insertarPalabra(palabra, pagina+1);
            }
        }
    }
    public String archivo(String ruta){
        try {
            File archivo = new File(ruta);
            FileReader fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            StringBuilder contenido = new StringBuilder();

            String texto = "";
            String linea;
            while ((linea = br.readLine()) != null) {
                contenido.append(linea);
            }
            return contenido.toString();
        } catch(Exception e) {
            return null;
        }
    }
    public void insertarPalabra(String key, int pagina) {
        raiz = insertarPalabra(raiz, key, pagina);
    }

    //Metodo de insertar
    private NodoAVL insertarPalabra(NodoAVL nodoActual, String llave, int pagina) {
        if (nodoActual == null) return (new NodoAVL(llave, pagina));
        if (llave.compareToIgnoreCase(nodoActual.llave) < 0){
            //es un < | "a".compareTo("b") == -1
            nodoActual.izquierda = insertarPalabra(nodoActual.izquierda, llave, pagina);
        } else if (llave.compareToIgnoreCase(nodoActual.llave) > 0){
            //es un > | "b".compareTo("a") == 1
            nodoActual.derecha = insertarPalabra(nodoActual.derecha, llave, pagina);
        }else{

            int repeticiones = nodoActual.paginas.getOrDefault(pagina, 0);
            if(repeticiones == 0){
                nodoActual.paginas.put(pagina, 1);
            }else{
                nodoActual.paginas.replace(pagina, repeticiones+1);
            }

            return nodoActual;
        }

        // Actualizacion de la altura
        nodoActual.altura = 1 + maximo(altura(nodoActual.izquierda), altura(nodoActual.derecha));

        // Se obtiene el factor de balance
        int balance = getBalance(nodoActual); // height(nodoActual.left) - height(nodoActual.right)

        // Caso Izquierda Izquierda
        if (balance > 1 && llave.compareToIgnoreCase(nodoActual.izquierda.llave) < 0) {
            return rotaDerecha(nodoActual);
        }

        // Caso Derecha Derecha
        if (balance < -1 && llave.compareToIgnoreCase(nodoActual.derecha.llave) > 0) {
            return rotaIzquierda(nodoActual);
        }

        // Caso Izquierda Derecha
        if (balance > 1 && llave.compareToIgnoreCase(nodoActual.izquierda.llave) > 0) {
            nodoActual.izquierda = rotaIzquierda(nodoActual.izquierda);
            return rotaDerecha(nodoActual);
        }

        // Caso Derecha Izquierda
        if (balance < -1 && llave.compareToIgnoreCase(nodoActual.derecha.llave) < 0) {
            nodoActual.derecha = rotaDerecha(nodoActual.derecha);
            return rotaIzquierda(nodoActual);
        }

        return nodoActual;
    }
}
