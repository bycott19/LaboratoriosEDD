//INTEGRANTES:
//Valentina Zuñiga - BAIRON MUÑOZ

class testColaBinomial{
    public static void main(String[] args) {

        System.out.println("*****Arreglo 1******");
        int a[] = {12, 17, 2, 4, 5, 6, 22, 21, 29, 32, 40, 45, 3, 54, 65};
        ColaBinomial b = new ColaBinomial();
        for (int i = 0; i < a.length; i++) b.Insert(a[i]);
        b.ImprimirArbol();
        System.out.println();
        System.out.print("Cantidad de nodos: "+b.size());
        System.out.println();

        System.out.println("*****Arreglo 2******");
        a = new int[]{12, 17};
        b = new ColaBinomial();
        for (int i=0; i < a.length;  i++) b.Insert(a[i]);
        b.ImprimirArbol();
        System.out.println();
        System.out.print("Cantidad de nodos: "+b.size());
        System.out.println();


        System.out.println("*****Arreglo 3******");
        a = new int[]{1, 2, 3, 4};
        b = new ColaBinomial();
        for (int i=0; i < a.length;  i++) b.Insert(a[i]);
        b.ImprimirArbol();
        System.out.println();
        System.out.print("Cantidad de nodos: "+b.size());
        System.out.println();

        System.out.println("");
        System.out.println("El costo de metodo size es O(N), basicamente por el ciclo for, ya que este se ejecutara n veces ");
        System.out.println("dependiendo de la cantidad de cabezeras que tenga la cola");
        System.out.println("El metodo size calcula la cantidad de nodos de la forma que hace 2^a la cantidad de hijos de la raiz");
    }
}