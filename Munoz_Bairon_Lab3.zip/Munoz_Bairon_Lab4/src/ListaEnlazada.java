public class ListaEnlazada {

    private Nodo cabeza;
    public ListaEnlazada(){
        this.cabeza = null;
    }

    public void ordenarLista(){
        Nodo actual = cabeza;
        while(actual != null){
            Nodo minimo = actual;
            Nodo siguiente = actual.siguiente;
            while (siguiente != null) {
                if (siguiente.dato < minimo.dato) {
                    minimo = siguiente;
                }
                siguiente = siguiente.siguiente;
            }
            int temp = actual.dato;
            actual.dato = minimo.dato;
            minimo.dato = temp;
            actual = actual.siguiente;
        }
    }
    public void agregarElemento(int dato) {
        Nodo nuevoNodo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Nodo temp = cabeza;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoNodo;
        }
    }

    public void imprimirLista() {
        Nodo temp = cabeza;
        while (temp != null) {
            System.out.print(temp.dato + " ");
            temp = temp.siguiente;
        }
        System.out.println();
    }
}
