public class Main {
    public static void main(String[]args){

        ListaEnlazada List = new ListaEnlazada();

        int numAleatorio;
        for(int i=0; i < 20; i++){
            numAleatorio = (int)(Math.random()*20);
            List.agregarElemento(numAleatorio);
        }
        System.out.println("Lista Original: ");
        List.imprimirLista();

        List.ordenarLista();
        System.out.println();
        System.out.println("Lista Ordenada");
        List.imprimirLista();
    }
}
