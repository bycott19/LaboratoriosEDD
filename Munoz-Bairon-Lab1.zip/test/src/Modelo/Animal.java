package Modelo;

import java.util.Date;

public class Animal {
    private String dueño;
    private String nombre;
    private String color;
    private int edad;
    private Date fechaNacimiento;

    public Animal(String dueño, String nombre, String color, int edad, Date fechaNacimiento) {
        this.dueño = dueño;
        this.nombre = nombre;
        this.color = color;
        this.edad = edad;
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getDueño() {
        return dueño;
    }

    public void setDueño(String dueño) {
        this.dueño = dueño;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
}
