package Modelo;

import java.util.Date;

public class Conejo extends Animal{
    public Conejo(String dueño, String nombre, String color, int edad, Date fechaNacimiento) {
        super(dueño, nombre, color, edad, fechaNacimiento);
    }
}
