package Modelo;

import java.util.Date;

public class Gato extends Animal{
    public Gato(String dueño, String nombre, String color, int edad, Date fechaNacimiento) {
        super(dueño, nombre, color, edad, fechaNacimiento);
    }
}
