package Vista;

import Controlador.ControladorVeterinaria;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class UIVeterinaria {
    private static UIVeterinaria instance = null;
    public static UIVeterinaria getInstance() {
        if (instance==null){
            instance = new UIVeterinaria();
        }
        return instance;
    }

    Scanner sc = new Scanner(System.in);

    public void menu() {

        int opcion = 0;
        String op;
        boolean repetir = true;

        do {
            System.out.println();
            System.out.println("------------------------------------");
            System.out.println("***** Menú veterinaria PetLove *****");
            System.out.println("");
            System.out.println("1. Listar animales registrados");
            System.out.println("2. Agregar nuevo animal al sistema");
            System.out.println("3. Dar de alta a un animal");
            System.out.println("4. Salir");
            do {
                System.out.print("Opción: ");
                op = sc.next();
                try {
                    opcion = Integer.parseInt(op);
                    if (opcion < 1 || opcion > 4) {
                        System.out.println("Opción fuera de rango");
                    } else {
                        repetir = false;
                    }
                } catch (Exception e) {
                    System.out.println("Se ingreso un caracter invalido");
                }
                switch (opcion) {
                    case 1:
                        listarAnimales();
                        break;
                    case 2:
                        agregarNuevoAnimal();
                        break;
                    case 3:
                        darDeAlta();
                        break;
                    case 4:
                        System.out.println("Adios");
                        break;
                }
            } while (repetir);
        } while (opcion != 4);
    }

    private void agregarNuevoAnimal(){

        boolean aux = true;
        int edad = 0;

        System.out.println();
        System.out.println("----------------------------");
        System.out.println("**** Ingresando animal *****");
        System.out.print("Especie del animal: ");
        String especie = sc.next();
        especieNoEncontrada(especie);
        System.out.print("RUT del dueño: ");
        String rut = sc.next();
        System.out.print("Nombre del animal: ");
        String nombre = sc.next();
        System.out.print("Color: ");
        String color = sc.next();
        do{
            System.out.print("Edad: ");
            String age = sc.next();
            try {
                edad = Integer.parseInt(age);
                while (edad < 1){
                    System.out.println("Edad no valida");
                    System.out.print("Edad: ");
                    age = sc.next();
                    edad = Integer.parseInt(age);
                }
                aux = false;
            }catch (Exception e){
                System.out.println("Caracter ingresado invalido");
            }
        }while (aux);
        aux = true;

        DateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaActual = new Date();
        do{
            System.out.println("Formato fecha: dd/MM/yyyy");
            System.out.print("Fecha Nacimiento: ");
            String fecha = sc.next();
            try {
                Date fechaNacimiento = formato.parse(fecha);

                boolean ValidacionFechaMayor = fechaNacimiento.after(fechaActual);
                boolean ValidacionFechaIgual = fechaNacimiento.equals(fechaActual);

                System.out.println("Fecha mayor: "+ValidacionFechaMayor);//si es mayor es true
                System.out.println("Fecha igual: "+ValidacionFechaIgual);// si es igual es false
                while (ValidacionFechaMayor == true || ValidacionFechaIgual ){
                    System.out.println("Fecha ingresada es mayor o igual a la fecha actual");
                    System.out.println("Formato fecha: dd/MM/yyyy");
                    System.out.print("Fecha Nacimiento: ");
                    fecha = sc.next();
                    fechaNacimiento = formato.parse(fecha);
                    ValidacionFechaMayor = fechaNacimiento.before(fechaActual);

                }
                while (ValidacionFechaIgual == false) {
                    System.out.println("Fecha ingresada es mayor o igual a la fecha actual");
                    System.out.println("Formato fecha: dd/MM/yyyy");
                    System.out.print("Fecha Nacimiento: ");
                    fecha = sc.next();
                    fechaNacimiento = formato.parse(fecha);
                    ValidacionFechaIgual = fechaNacimiento.equals(fechaActual);

                }

                aux = false;
                ControladorVeterinaria.getInstance().creaAnimal(rut,nombre,color,edad,fechaNacimiento,especie);
                System.out.println("Se ha ingresado con exito!!!");
                System.out.println("Final codigo");
                System.out.print("la fecha es igual: "+ValidacionFechaIgual);
                System.out.print("la fecha es mayor: "+ValidacionFechaMayor);
            }catch (Exception e){
                System.out.println("Se ingreso un formato de fecha invalido.");
            }
        }while(aux);
    }
    private void darDeAlta(){
        if(ControladorVeterinaria.getInstance().sinDatos() == true){
            return;
        }
        System.out.println();
        System.out.println("-----------------------");
        System.out.println("**** Dando de alta ****");
        System.out.print("Ingrese el RUT del dueño: ");
        String rut = sc.next();
        rutNoEncontrado(rut);
        System.out.print("Ingrese la especie: ");
        String especie = sc.next();
        especieNoEncontrada(especie);
        System.out.print("Ingrese el nombre del animal: ");
        String nombre = sc.next();
        if(ControladorVeterinaria.getInstance().darAlta(especie, rut, nombre) == true){
            System.out.println("Dado de alta con exito!!!");
        }else {
            System.out.println("No se ha podido dar de alta");
        }
    }

    private void listarAnimales(){
        if(ControladorVeterinaria.getInstance().sinDatos() == true){
            return;
        }
        System.out.println();
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("%-20s %-20s %-20s %-20s %-20s %-20s %n", "Especie", "Dueño", "Nombre", "Color", "Edad", "Fecha Nacimiento");
        ControladorVeterinaria.getInstance().listar();
    }

    public void especieNoEncontrada(String especie){
        while (ControladorVeterinaria.getInstance().especieNoRegistrada(especie) == true){
            System.out.println("----------------------------------------");
            System.out.println("La especie ingresada no esta disponible.");
            System.out.print("Especie del animal: ");
            especie = sc.next();
        }
    }
    public void rutNoEncontrado(String rut){
        while (ControladorVeterinaria.getInstance().dueñoNoEncontrado(rut) == true){
            System.out.println("------------------------------------");
            System.out.println("El RUT ingresado no se ha encontrado");
            System.out.print("Ingrese el RUT del dueño: ");
            rut = sc.next();
        }
    }
}
