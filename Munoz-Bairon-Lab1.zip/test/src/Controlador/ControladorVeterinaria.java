package Controlador;

import Modelo.Animal;
import Modelo.Conejo;
import Modelo.Gato;
import Modelo.Perro;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ControladorVeterinaria {
    private static ControladorVeterinaria instance = null;
    public static ControladorVeterinaria getInstance() {
        if (instance==null){
            instance = new ControladorVeterinaria();
        }
        return instance;
    }
    ArrayList<Animal> animals = new ArrayList<>();
    ArrayList<Perro> perros = new ArrayList<>();
    ArrayList<Gato> gatos = new ArrayList<>();
    ArrayList<Conejo> conejos = new ArrayList<>();

    public boolean sinDatos(){
        if(perros.size() == 0 && gatos.size() == 0 && conejos.size() == 0){
            System.out.println("No existe registro de animales en el sistema");
            return true;
        }
        return false;
    }
    public boolean especieNoRegistrada(String especie){
        if(especie.equalsIgnoreCase("gato") || especie.equalsIgnoreCase("perro") || especie.equalsIgnoreCase("conejo")){
            return false;
        }
        return true;
    }
    public boolean dueñoNoEncontrado(String rut){
        for (Animal dueño : animals){
            if (dueño.getDueño().equals(rut) ){
                return false;
            }
        }
        return true;
    }
    public void creaAnimal(String rut, String name, String color, int edad, Date fecha, String especie){
        switch (especie.toLowerCase()){
            case "perro":
                Perro dog = new Perro(rut, name, color, edad, fecha);
                perros.add(dog);
                animals.add(dog);
                break;
            case "gato":
                Gato cat = new Gato(rut, name, color, edad, fecha);
                gatos.add(cat);
                animals.add(cat);
                break;
            case "conejo":
                Conejo rabbit = new Conejo(rut, name, color, edad, fecha);
                conejos.add(rabbit);
                animals.add(rabbit);
                break;
        }
    }
    public boolean darAlta(String especie, String rut, String nombre){
        switch (especie.toLowerCase()){
            case "perro":
                for(Perro perro : perros){
                    if(perro.getDueño().equals(rut) && perro.getNombre().equalsIgnoreCase(nombre)){
                        perros.remove(perro);
                        return true;
                    }
                }
                break;
            case "gato":
                for(Gato gato : gatos) {
                    if (gato.getDueño().equals(rut) && gato.getNombre().equalsIgnoreCase(nombre)) {
                        gatos.remove(gato);
                        return true;
                    }
                }
                break;
            case "conejo":
                for(Conejo conejo : conejos){
                    if(conejo.getDueño().equals(rut) && conejo.getNombre().equalsIgnoreCase(nombre)){
                        conejos.remove(conejo);
                        return true;
                    }
                }
                break;
        }
        return false;
    }
    public void listar(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        if(perros.size() > 0){
            System.out.printf("%-20s %n","Perros:");
            for(Perro animal : perros ){
                System.out.printf("%-20s %-20s %-20s %-20s %-20d %-20s %n", " ", animal.getDueño(), animal.getNombre(), animal.getColor(), animal.getEdad(), dateFormat.format(animal.getFechaNacimiento()));
            }
        }
        if(gatos.size() > 0){
            System.out.printf("%-20s %n","Gatos:");
            for(Gato animal : gatos){
                System.out.printf("%-20s %-20s %-20s %-20s %-20d %-20s %n", " ", animal.getDueño(), animal.getNombre(), animal.getColor(), animal.getEdad(), dateFormat.format(animal.getFechaNacimiento()));
            }
        }
        if (conejos.size() > 0) {
            System.out.printf("%-20s %n","Conejos:");
            for(Conejo animal : conejos){
                System.out.printf("%-20s %-20s %-20s %-20s %-20d %-20s %n", " ", animal.getDueño(), animal.getNombre(), animal.getColor(), animal.getEdad(), dateFormat.format(animal.getFechaNacimiento()));
            }
        }
        System.out.println();
    }

}
