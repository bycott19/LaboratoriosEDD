import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        
        ArrayList<Nodo> miLista = new ArrayList<>();
        Nodo miNodito = new Nodo();
        miNodito.llenarArray(miLista);

        System.out.println("Lista original: ");
        miNodito.listarArray(miLista);

        Collections.sort(miLista, Comparator.comparingInt(nodo -> nodo.getDato()));
        System.out.println("Lista Ordenada");
        miNodito.listarArray(miLista);
    }
}