import java.util.ArrayList;

public class Nodo {

    private int id;
    private int dato;

    public Nodo(int id, int dato) {
        this.id = id;
        this.dato = dato;
    }

    public Nodo() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDato() {
        return dato;
    }

    public void setDato(int dato) {
        this.dato = dato;
    }

    public void llenarArray(ArrayList<Nodo> miLista){
        int numAleatorio;
        for(int i=0; i < 10; i++){
            numAleatorio = (int)(Math.random()*9+1);
            Nodo nodo = new Nodo(i, numAleatorio);
            miLista.add(nodo);
        }
    }
    public void listarArray(ArrayList<Nodo> miLista){
        for(Nodo miNodo : miLista){
            System.out.println("Id: "+miNodo.getId()+" Elemento: "+miNodo.getDato());
        }
    }
}
