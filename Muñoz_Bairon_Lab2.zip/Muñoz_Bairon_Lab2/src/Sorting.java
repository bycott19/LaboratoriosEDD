import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Sorting {

    public static int[] fillArray(int n) {
        int[] array = new int[n];
        Random rnd = new Random();
        for (int i = 0; i < array.length; i++) {
            array[i] = rnd.nextInt(n * 10);
        }
        return array;
    }

    public static void bubbleSort(int array[]) {
        int n = array.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (array[j] > array[j + 1]) {
                    // swap arr[j+1] and arr[j]
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
    }

    public static void merge(int array[], int l, int m, int r) {
        // Find sizes of two subarrays to be merged
        int n1 = m - l + 1;
        int n2 = r - m;

        /* Create temp arrays */
        int L[] = new int[n1];
        int R[] = new int[n2];

        /* Copy data to temp arrays */
        for (int i = 0; i < n1; ++i)
            L[i] = array[l + i];
        for (int j = 0; j < n2; ++j)
            R[j] = array[m + 1 + j];

        /* Merge the temp arrays */

        // Initial indexes of first and second subarrays
        int i = 0, j = 0;

        // Initial index of merged subarray array
        int k = l;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                array[k] = L[i];
                i++;
            } else {
                array[k] = R[j];
                j++;
            }
            k++;
        }

        /* Copy remaining elements of L[] if any */
        while (i < n1) {
            array[k] = L[i];
            i++;
            k++;
        }

        /* Copy remaining elements of R[] if any */
        while (j < n2) {
            array[k] = R[j];
            j++;
            k++;
        }
    }

    // Main function that sorts arr[l..r] using
    // merge()
    public static void sort(int array[], int l, int r) {
        if (l < r) {
            // Find the middle point
            int m = l + (r - l) / 2;

            // Sort first and second halves
            sort(array, l, m);
            sort(array, m + 1, r);

            // Merge the sorted halves
            merge(array, l, m, r);
        }
    }

    public static void mergeSort(int array[]) {
        sort(array, 0, array.length - 1);
    }
    public static void print(int array[]) {
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {

        long startTime;
        long finishTime;

        long data[][] = new long[9][3];
        int n1 = 1000, n2 = 5000, n3 = 10000, n4 = 50000, n5 = 100000, n6 = 1000000, n7 = 5000000, n8 = 10000000, n9 = 50000000;

        int arr_1[] = fillArray(n1);
        int arr_2[] = fillArray(n1);

        startTime = System.nanoTime();
        bubbleSort(arr_1);
        finishTime = System.nanoTime() - startTime;
        data[0][0] = finishTime;

        startTime = System.nanoTime();
        bubbleSort(arr_2);
        finishTime = System.nanoTime() - startTime;
        data[0][0] = (data[0][0]+finishTime) / 2;

        startTime = System.nanoTime();
        mergeSort(arr_1);
        finishTime = System.nanoTime() - startTime;
        data[0][1] = finishTime;

        startTime = System.nanoTime();
        mergeSort(arr_2);
        finishTime = System.nanoTime() - startTime;
        data[0][1] = (data[0][1]+finishTime) / 2;

        startTime = System.nanoTime();
        Arrays.sort(arr_1);
        finishTime = System.nanoTime() - startTime;
        data[0][2] = finishTime;

        startTime = System.nanoTime();
        Arrays.sort(arr_2);
        finishTime = System.nanoTime() - startTime;
        data[0][2] = (data[0][2]+finishTime) / 2;


        int arr_3[] = fillArray(n2);
        int arr_4[] = fillArray(n2);
        startTime = System.nanoTime();
        bubbleSort(arr_3);
        finishTime = System.nanoTime() - startTime;
        data[1][0] = finishTime;

        startTime = System.nanoTime();
        bubbleSort(arr_4);
        finishTime = System.nanoTime() - startTime;
        data[1][0] = (data[1][0]+finishTime) / 2;

        startTime = System.nanoTime();
        mergeSort(arr_3);
        finishTime = System.nanoTime() - startTime;
        data[1][1] = finishTime;

        startTime = System.nanoTime();
        mergeSort(arr_4);
        finishTime = System.nanoTime() - startTime;
        data[1][1] = (data[1][1]+finishTime) / 2;

        startTime = System.nanoTime();
        Arrays.sort(arr_3);
        finishTime = System.nanoTime() - startTime;
        data[1][2] = finishTime;

        startTime = System.nanoTime();
        Arrays.sort(arr_4);
        finishTime = System.nanoTime() - startTime;
        data[1][2] = (data[1][2]+finishTime) / 2;


        int arr_5[] = fillArray(n3);
        int arr_6[] = fillArray(n3);
        startTime = System.nanoTime();
        bubbleSort(arr_5);
        finishTime = System.nanoTime() - startTime;
        data[2][0] = finishTime;

        startTime = System.nanoTime();
        bubbleSort(arr_6);
        finishTime = System.nanoTime() - startTime;
        data[2][0] = (data[2][0]+finishTime) / 2;

        startTime = System.nanoTime();
        mergeSort(arr_5);
        finishTime = System.nanoTime() - startTime;
        data[2][1] = finishTime;

        startTime = System.nanoTime();
        mergeSort(arr_6);
        finishTime = System.nanoTime() - startTime;
        data[2][1] = (data[2][1]+finishTime) / 2;

        startTime = System.nanoTime();
        Arrays.sort(arr_5);
        finishTime = System.nanoTime() - startTime;
        data[2][2] = finishTime;

        startTime = System.nanoTime();
        Arrays.sort(arr_6);
        finishTime = System.nanoTime() - startTime;
        data[2][2] = (data[2][2]+finishTime) / 2;

        int arr_7[] = fillArray(n4);
        int arr_8[] = fillArray(n4);
        startTime = System.nanoTime();
        bubbleSort(arr_7);
        finishTime = System.nanoTime() - startTime;
        data[3][0] = finishTime;

        startTime = System.nanoTime();
        bubbleSort(arr_8);
        finishTime = System.nanoTime() - startTime;
        data[3][0] = (data[3][0]+finishTime) / 2;

        startTime = System.nanoTime();
        mergeSort(arr_7);
        finishTime = System.nanoTime() - startTime;
        data[3][1] = finishTime;

        startTime = System.nanoTime();
        mergeSort(arr_8);
        finishTime = System.nanoTime() - startTime;
        data[3][1] = (data[3][1]+finishTime) / 2;

        startTime = System.nanoTime();
        Arrays.sort(arr_7);
        finishTime = System.nanoTime() - startTime;
        data[3][2] = finishTime;

        startTime = System.nanoTime();
        Arrays.sort(arr_8);
        finishTime = System.nanoTime() - startTime;
        data[3][2] = (data[3][2]+finishTime) / 2;


        int arr_9[] = fillArray(n5);
        int arr_10[] = fillArray(n5);
        startTime = System.nanoTime();
        bubbleSort(arr_10);
        finishTime = System.nanoTime() - startTime;
        data[4][0] = (data[4][0]+finishTime) / 2;

        startTime = System.nanoTime();
        mergeSort(arr_9);
        finishTime = System.nanoTime() - startTime;
        data[4][1] = finishTime;

        startTime = System.nanoTime();
        mergeSort(arr_10);
        finishTime = System.nanoTime() - startTime;
        data[4][1] = (data[4][1]+finishTime) / 2;

        startTime = System.nanoTime();
        Arrays.sort(arr_9);
        finishTime = System.nanoTime() - startTime;
        data[4][2] = finishTime;

        startTime = System.nanoTime();
        Arrays.sort(arr_10);
        finishTime = System.nanoTime() - startTime;
        data[4][2] = (data[4][2]+finishTime) / 2;

        int arr_11[] = fillArray(n6);
        int arr_12[] = fillArray(n6);
        startTime = System.nanoTime();
        mergeSort(arr_11);
        finishTime = System.nanoTime() - startTime;
        data[5][1] = finishTime;

        startTime = System.nanoTime();
        mergeSort(arr_12);
        finishTime = System.nanoTime() - startTime;
        data[5][1] = (data[5][1]+finishTime) / 2;

        startTime = System.nanoTime();
        Arrays.sort(arr_11);
        finishTime = System.nanoTime() - startTime;
        data[5][2] = finishTime;

        startTime = System.nanoTime();
        Arrays.sort(arr_12);
        finishTime = System.nanoTime() - startTime;
        data[5][2] = (data[5][2]+finishTime) / 2;


        int arr_13[] = fillArray(n7);
        int arr_14[] = fillArray(n7);

        startTime = System.nanoTime();
        mergeSort(arr_13);
        finishTime = System.nanoTime() - startTime;
        data[6][1] = finishTime;

        startTime = System.nanoTime();
        mergeSort(arr_14);
        finishTime = System.nanoTime() - startTime;
        data[6][1] = (data[6][1]+finishTime) / 2;

        startTime = System.nanoTime();
        Arrays.sort(arr_13);
        finishTime = System.nanoTime() - startTime;
        data[6][2] = finishTime;

        startTime = System.nanoTime();
        Arrays.sort(arr_14);
        finishTime = System.nanoTime() - startTime;
        data[6][2] = (data[6][2]+finishTime) / 2;

        int arr_15[] = fillArray(n8);
        int arr_16[] = fillArray(n8);
        startTime = System.nanoTime();
        mergeSort(arr_15);
        finishTime = System.nanoTime() - startTime;
        data[7][1] = finishTime;

        startTime = System.nanoTime();
        mergeSort(arr_16);
        finishTime = System.nanoTime() - startTime;
        data[7][1] = (data[7][1]+finishTime) / 2;

        startTime = System.nanoTime();
        Arrays.sort(arr_15);
        finishTime = System.nanoTime() - startTime;
        data[7][2] = finishTime;

        startTime = System.nanoTime();
        Arrays.sort(arr_16);
        finishTime = System.nanoTime() - startTime;
        data[7][2] = (data[7][2]+finishTime) / 2;


        int arr_17[] = fillArray(n9);
        int arr_18[] = fillArray(n9);
        startTime = System.nanoTime();
        mergeSort(arr_17);
        finishTime = System.nanoTime() - startTime;
        data[8][1] = finishTime;

        startTime = System.nanoTime();
        mergeSort(arr_18);
        finishTime = System.nanoTime() - startTime;
        data[8][1] = (data[8][1]+finishTime) / 2;

        startTime = System.nanoTime();
        Arrays.sort(arr_17);
        finishTime = System.nanoTime() - startTime;
        data[8][2] = finishTime;

        startTime = System.nanoTime();
        Arrays.sort(arr_18);
        finishTime = System.nanoTime() - startTime;
        data[8][2] = (data[8][2]+finishTime) / 2;


        imprimir(data);
    }
    public static void imprimir(long data[][]){
        for (int x=0; x < data.length; x++) {
            System.out.print("|");
            for (int y=0; y < data[x].length; y++) {
                if((x==4 || x==5 || x==6 || x==7 || x==8) && y==0){
                    System.out.println("---");
                }else{
                    System.out.print (data[x][y]);
                }
                if (y!=data[x].length-1)
                    System.out.print("\t");
            }
            System.out.println("|");
        }
        System.out.println();
        System.out.println("En conclusión con este ejercicio se logro observar que, el código puede llegar a ser muy ineficiente \n" +
                "cuando se trabaja con números grandes, por eso debemos escoger la mejor estructura para tener un codigo \n" +
                "más eficiente, por ejemplo, en este ejercicio el metodo bubbleSort, llego a ser muy ineficiente con los \n" +
                "últimos números de arreglo (demoraba demasiado tiempo-estuve más de 30 min y no dio resultado), por lo \n" +
                "que su cálculo fue omitido");

    }

}