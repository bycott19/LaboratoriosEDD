public class Arbol {
    public NodoArbol raiz;

    public Arbol(){
        raiz=null;
    }
    public void insertar(int dato) {
        raiz = insertarRec(raiz, dato);
    }

    private NodoArbol insertarRec(NodoArbol nodo, int dato) {
        if (nodo == null) {
            return new NodoArbol(dato);
        }

        if (dato < nodo.dato) {
            nodo.izquierda = insertarRec(nodo.izquierda, dato);
        } else if (dato > nodo.dato) {
            nodo.derecha = insertarRec(nodo.derecha, dato);
        }
        return nodo;
    }
   
    public void mostrarNodos(NodoArbol nodo) {
        if (nodo != null) {
            mostrarNodos(nodo.izquierda);
            System.out.print(nodo.dato + " ");
            mostrarNodos(nodo.derecha);
        }
    }
    public void mostrarNodos() {
        mostrarNodos(raiz);
        System.out.println(); // Agregar una nueva línea al final para formatear la salida
    }
}

