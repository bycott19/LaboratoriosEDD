/*Escribe un metodo para la clase árbol (árbol n-ario) que devuelva el número de nodos que forman el árbol*/

public class Main {
    public static void main(String[] args) {

        Arbol arbol = new Arbol();
        int cantidadDeNodos = (int) (Math.random() * 20);

        System.out.println("Cantidad de nodos en el árbol: " + cantidadDeNodos);

        for (int i = 0; i < cantidadDeNodos; i++) {
            int datoAleatorio = (int) (Math.random() * 100);
            arbol.insertar(datoAleatorio);
        }

        System.out.println("Datos de los nodos en orden:");
        arbol.mostrarNodos();
    }
}