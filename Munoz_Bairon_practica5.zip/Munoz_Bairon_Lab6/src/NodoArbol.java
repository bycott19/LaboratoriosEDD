public class NodoArbol {

    int dato;
    NodoArbol izquierda, derecha;

    public NodoArbol(int dato, NodoArbol izquierda, NodoArbol derecha) {
        this.dato = dato;
        this.izquierda = null;
        this.derecha = null;
    }

    public NodoArbol(int dato) {
    }

    public int getDato() {
        return dato;
    }

    public void setDato(int dato) {
        this.dato = dato;
    }

    public NodoArbol getIzquierda() {
        return izquierda;
    }

    public void setIzquierda(NodoArbol izquierda) {
        this.izquierda = izquierda;
    }

    public NodoArbol getDerecha() {
        return derecha;
    }

    public void setDerecha(NodoArbol derecha) {
        this.derecha = derecha;
    }
}
