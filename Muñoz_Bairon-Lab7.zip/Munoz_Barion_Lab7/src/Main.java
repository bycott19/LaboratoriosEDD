import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Abb a = new Abb();
        int complementoNum, numero;
        a.Insertar(10);
        a.Insertar(-8);
        a.Insertar(12);
        a.Insertar(4);
        a.Insertar(-7);

        do {
            //Puede borrarlos de arriba hacia abajo:
            /* Arbol:
             10
                -8
                   4
                      -7
                 12
            no entiendo muy bien como borra, por ejemplo no puedo borrar el 4, -7 ni el 12 al inicio, pero puedo borrar el -8 y el 10
            si borro el -8 puedo borrar el 10, 4, -7, pero no el 12, el 12 es el ultimo que me deja borrar, talvez por el recorrido
            */
            a.Imprimir();
            System.out.println("Numero: ");
            numero = sc.nextInt();
            complementoNum = numero * -1;

            if(a.Complemento(numero)==true){
                System.out.println(a.Complemento(numero));    // Retorna True, ya que existe el -8 en el árbol
                a.Eliminar(complementoNum);
            }else{
                System.out.println(a.Complemento(numero));    // Retorna False, ya que se quitó el -8 en el árbol
            }
        } while (true);
    }
}